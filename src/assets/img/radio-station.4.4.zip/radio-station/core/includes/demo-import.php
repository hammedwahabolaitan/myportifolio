<?php 
	if(isset($_GET['import-demo']) && $_GET['import-demo'] == true){
		// ------- Create Nav Menu --------
		$radio_station_menuname ='Main Menus';
	    $radio_station_bpmenulocation = 'main-menu';
	    $radio_station_menu_exists = wp_get_nav_menu_object( $radio_station_menuname );
	    if( !$radio_station_menu_exists){
	        $radio_station_menu_id = wp_create_nav_menu($radio_station_menuname);
	        $radio_station_home_parent = wp_update_nav_menu_item($radio_station_menu_id, 0, array(
				'menu-item-title' =>  __('Home','radio-station'),
				'menu-item-classes' => 'home',
				'menu-item-url' =>home_url( '/' ),
				'menu-item-status' => 'publish')
			);

			wp_update_nav_menu_item($radio_station_menu_id, 0, array(
	            'menu-item-title' =>  __('Browse','radio-station'),
	            'menu-item-classes' => 'browse',
	            'menu-item-url' => home_url( '//features/' ),
	            'menu-item-status' => 'publish'));

	        wp_update_nav_menu_item($radio_station_menu_id, 0, array(
	            'menu-item-title' =>  __('Radio','radio-station'),
	            'menu-item-classes' => 'radio',
	            'menu-item-url' => home_url( '//products/' ), 
	            'menu-item-status' => 'publish'));

			wp_update_nav_menu_item($radio_station_menu_id, 0, array(
	            'menu-item-title' =>  __('More','radio-station'),
	            'menu-item-classes' => 'more',
	            'menu-item-url' => home_url( '//support/' ), 
	            'menu-item-status' => 'publish'));

			wp_update_nav_menu_item($radio_station_menu_id, 0, array(
	            'menu-item-title' =>  __('Contact Us','radio-station'),
	            'menu-item-classes' => 'contact',
	            'menu-item-url' => home_url( '//pricing/' ), 
	            'menu-item-status' => 'publish'));
	        
			if( !has_nav_menu( $radio_station_bpmenulocation ) ){
	            $locations = get_theme_mod('nav_menu_locations');
	            $locations[$radio_station_bpmenulocation] = $radio_station_menu_id;
	            set_theme_mod( 'nav_menu_locations', $locations );
	        }
	    }
	    $radio_station_home_id='';
		$radio_station_home_content = '';
		$radio_station_home_title = 'Home';
		$home = array(
			'post_type' => 'page',
			'post_title' => $radio_station_home_title,
			'post_content' => $radio_station_home_content,
			'post_status' => 'publish',
			'post_author' => 1,
			'post_slug' => 'home'
		);
		$radio_station_home_id = wp_insert_post($home);
	    
		add_post_meta( $radio_station_home_id, '_wp_page_template', 'frontpage.php' );

		update_option( 'page_on_front', $radio_station_home_id );
		update_option( 'show_on_front', 'page' );

		//---Header--//

		set_theme_mod( 'radio_station_search_box_enable', true);

		//-----Slider-----//

		set_theme_mod( 'radio_station_blog_box_enable', true);

		set_theme_mod('radio_station_social_links_settings', array(
            array(
                "link_text" => "fab fa-facebook-f",
                "link_url" => "#"
            ),
            array(
                "link_text" => "fab fa-twitter",
                "link_url" => "#"
            ),
            array(
                "link_text" => "fab fa-whatsapp",
                "link_url" => "#"
            ),
            array(
                "link_text" => "fab fa-instagram",
                "link_url" => "#"
            )
            
        ));

		set_theme_mod( 'radio_station_blog_slide_number', '3' );
		$radio_station_latest_post_category = wp_create_category('Slider Post');
			set_theme_mod( 'radio_station_blog_slide_category', 'Slider Post' ); 
			set_theme_mod( 'radio_station_slider_first_heading', 'Get Started Our Radio Show' );

		for($i=1; $i<=3; $i++) {

			$slider_title=array('Best Music To Suit All of Your Mood', 'Songs that resonate with every feeling you have.', 'The ideal music to complement any mood.');

			// Create post object
			$radio_station_my_post = array(
				'post_title'    => wp_strip_all_tags( $slider_title[$i-1] ),
				'post_status'   => 'publish',
				'post_type'     => 'post',
				'post_category' => array($radio_station_latest_post_category) 
			);

			// Insert the post into the database
			$radio_station_post_id = wp_insert_post( $radio_station_my_post );

			$radio_station_image_url = get_template_directory_uri().'/assets/images/slider'.$i.'.png';

			$radio_station_image_name= 'slider'.$i.'.png';
			$radio_station_upload_dir       = wp_upload_dir(); 
			// Set upload folder
			$radio_station_image_data       = file_get_contents($radio_station_image_url); 
			 
			// Get image data
			$radio_station_unique_file_name = wp_unique_filename( $radio_station_upload_dir['path'], $radio_station_image_name ); 
			// Generate unique name
			$filename= basename( $radio_station_unique_file_name ); 
			// Create image file name
			// Check folder permission and define file location
			if( wp_mkdir_p( $radio_station_upload_dir['path'] ) ) {
				$file = $radio_station_upload_dir['path'] . '/' . $filename;
			} else {
				$file = $radio_station_upload_dir['basedir'] . '/' . $filename;
			}
			file_put_contents( $file, $radio_station_image_data );
			$wp_filetype = wp_check_filetype( $filename, null );
			$radio_station_attachment = array(
				'post_mime_type' => $wp_filetype['type'],
				'post_title'     => sanitize_file_name( $filename ),
				'post_content'   => '',
				'post_type'     => 'post',
				'post_status'    => 'inherit'
			);
			$attach_id = wp_insert_attachment( $radio_station_attachment, $file, $radio_station_post_id );
			require_once(ABSPATH . 'wp-admin/includes/image.php');
			$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
				wp_update_attachment_metadata( $attach_id, $attach_data );
				set_post_thumbnail( $radio_station_post_id, $attach_id );
		}

		// //-----Radio Category Section-----//


		set_theme_mod( 'radio_station_radio_category_section_enable', true);

		set_theme_mod( 'radio_station_radio_category_number', '12' );
		$radio_station_latest_post_category_1 = wp_create_category('Latest Updates');
			set_theme_mod( 'radio_station_radio_category', 'Latest Updates' );
			set_theme_mod( 'radio_station_radio_category_first_heading', 'Categories' ); 
			set_theme_mod( 'radio_station_radio_category_second_heading', 'Our Categories' ); 

		for($i=1; $i<=12; $i++) {

			$title=array('Drum & Bass', 'Rap Songs', 'Hip Hop', 'Electro', 'Jazz', 'Lounge', 'Disco', 'Downtempo', 'House', 'City Song', 'Classic', 'Pop Song');

			// Create post object
			$radio_station_my_post_1 = array(
				'post_title'    => wp_strip_all_tags( $title[$i-1] ),
				'post_status'   => 'publish',
				'post_type'     => 'post',
				'post_category' => array($radio_station_latest_post_category_1) 
			);

			// Insert the post into the database
			$radio_station_post_id_1 = wp_insert_post( $radio_station_my_post_1 );

			$radio_station_image_url = get_template_directory_uri().'/assets/images/cat'.$i.'.png';

			$radio_station_image_name_1= 'cat'.$i.'.png';
			$radio_station_upload_dir_1       = wp_upload_dir(); 
			// Set upload folder
			$radio_station_image_data_1       = file_get_contents($radio_station_image_url); 
			 
			// Get image data
			$radio_station_unique_file_name_1 = wp_unique_filename( $radio_station_upload_dir_1['path'], $radio_station_image_name_1 ); 
			// Generate unique name
			$filename= basename( $radio_station_unique_file_name_1 ); 
			// Create image file name
			// Check folder permission and define file location
			if( wp_mkdir_p( $radio_station_upload_dir_1['path'] ) ) {
				$file = $radio_station_upload_dir_1['path'] . '/' . $filename;
			} else {
				$file = $radio_station_upload_dir_1['basedir'] . '/' . $filename;
			}
			file_put_contents( $file, $radio_station_image_data_1 );
			$wp_filetype = wp_check_filetype( $filename, null );
			$radio_station_attachment_1 = array(
				'post_mime_type' => $wp_filetype['type'],
				'post_title'     => sanitize_file_name( $filename ),
				'post_content'   => '',
				'post_type'     => 'post',
				'post_status'    => 'inherit'
			);
			$attach_id = wp_insert_attachment( $radio_station_attachment_1, $file, $radio_station_post_id_1 );
			require_once(ABSPATH . 'wp-admin/includes/image.php');
			$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
				wp_update_attachment_metadata( $attach_id, $attach_data );
				set_post_thumbnail( $radio_station_post_id_1, $attach_id );
		}
	}
?>