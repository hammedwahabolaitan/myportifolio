<?php

if ( class_exists("Kirki")){

	// LOGO

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'slider',
		'settings'    => 'radio_station_logo_resizer',
		'label'       => esc_html__( 'Adjust Your Logo Size ', 'radio-station' ),
		'section'     => 'title_tagline',
		'default'     => 70,
		'choices'     => [
			'min'  => 10,
			'max'  => 300,
			'step' => 10,
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_logo_text',
		'section'     => 'title_tagline',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Site Title and Tagline', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_display_header_title',
		'label'       => esc_html__( 'Site Title Enable / Disable Button', 'radio-station' ),
		'section'     => 'title_tagline',
		'default'     => '1',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_display_header_text',
		'label'       => esc_html__( 'Tagline Enable / Disable Button', 'radio-station' ),
		'section'     => 'title_tagline',
		'default'     => false,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	//FONT STYLE TYPOGRAPHY

	Kirki::add_panel( 'radio_station_panel_id', array(
	    'priority'    => 10,
	    'title'       => esc_html__( 'Typography', 'radio-station' ),
	) );

	Kirki::add_section( 'radio_station_font_style_section', array(
		'title'      => esc_html__( 'Typography Option',  'radio-station' ),
		'priority'   => 2,
		'capability' => 'edit_theme_options',
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_font_style_section',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. More Font Family Options </p><p>3. Color Pallete Setup </p><p>4. Section Reordering Facility</p><p>5. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_all_headings_typography',
		'section'     => 'radio_station_font_style_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Heading Of All Sections',  'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

	Kirki::add_field( 'global', array(
		'type'        => 'typography',
		'settings'    => 'radio_station_all_headings_typography',
		'label'       => esc_html__( 'Heading Typography',  'radio-station' ),
		'description' => esc_html__( 'Select the typography options for your heading.',  'radio-station' ),
		'section'     => 'radio_station_font_style_section',
		'priority'    => 10,
		'default'     => array(
			'font-family'    => '',
			'variant'        => '',
		),
		'output' => array(
			array(
				'element' => array( 'h1','h2','h3','h4','h5','h6', ),
			),
		),
	) );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_body_content_typography',
		'section'     => 'radio_station_font_style_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Body Content',  'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

	Kirki::add_field( 'global', array(
		'type'        => 'typography',
		'settings'    => 'radio_station_body_content_typography',
		'label'       => esc_html__( 'Content Typography',  'radio-station' ),
		'description' => esc_html__( 'Select the typography options for your heading.',  'radio-station' ),
		'section'     => 'radio_station_font_style_section',
		'priority'    => 10,
		'default'     => array(
			'font-family'    => '',
			'variant'        => '',
		),
		'output' => array(
			array(
				'element' => array( 'body', ),
			),
		),
	) );

		// PANEL
	Kirki::add_panel( 'radio_station_panel_id_5', array(
	    'priority'    => 10,
	    'title'       => esc_html__( 'Theme Animations', 'radio-station' ),
	) );

	// ANIMATION SECTION
	Kirki::add_section( 'radio_station_section_animation', array(
	    'title'          => esc_html__( 'Animations', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id_5',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_section_animation',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	]);

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_animation_enabled',
		'label'       => esc_html__( 'Turn On To Show Animation', 'radio-station' ),
		'section'     => 'radio_station_section_animation',
		'default'     => true,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

		// PANEL
	Kirki::add_panel( 'radio_station_panel_id_2', array(
	    'priority'    => 10,
	    'title'       => esc_html__( 'Theme Dark Mode', 'radio-station' ),
	) );

	// DARK MODE SECTION
	Kirki::add_section( 'radio_station_section_dark_mode', array(
	    'title'          => esc_html__( 'Dark Mode', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id_2',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_section_dark_mode',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	]);

	Kirki::add_field( 'theme_config_id', [
	    'type'        => 'custom',
	    'settings'    => 'radio_station_dark_colors',
	    'section'     => 'radio_station_section_dark_mode',
	    'default'     => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Dark Appearance', 'radio-station' ) . '</h3>',
	    'priority'    => 10,
	]);

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_is_dark_mode_enabled',
		'label'       => esc_html__( 'Turn To Dark Mode', 'radio-station' ),
		'section'     => 'radio_station_section_dark_mode',
		'default'     => false,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	// PANEL

	Kirki::add_panel( 'radio_station_panel_id', array(
	    'priority'    => 10,
	    'title'       => esc_html__( 'Theme Options', 'radio-station' ),
	) );

	Kirki::add_section( 'radio_station_section_color', array(
	    'title'          => esc_html__( 'Global Color', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_section_color',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_global_colors',
		'section'     => 'radio_station_section_color',
		'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Here you can change your theme color on one click.', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'color',
		'settings'    => 'radio_station_global_color',
		'label'       => __( 'choose your Appropriate Color', 'radio-station' ),
		'section'     => 'radio_station_section_color',
		'default'     => '#89cc88',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'color',
		'settings'    => 'radio_station_global_color_2',
		'label'       => __( 'Choose Your Second Color', 'radio-station' ),
		'section'     => 'radio_station_section_color',
		'default'     => '#0ec08e',
	] );


	// Additional Settings

	Kirki::add_section( 'radio_station_additional_settings', array(
	    'title'          => esc_html__( 'Additional Settings', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_additional_settings',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_scroll_enable_setting',
		'label'       => esc_html__( 'Here you can enable or disable your scroller.', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => '1',
		'priority'    => 10,
	] );

	new \Kirki\Field\Radio_Buttonset([
		'settings'    => 'radio_station_scroll_top_position',
		'label'       => esc_html__( 'Alignment for Scroll To Top', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => 'Right',
		'priority'    => 10,
		'choices'     => [
			'Left'   => esc_html__( 'Left', 'radio-station' ),
			'Center' => esc_html__( 'Center', 'radio-station' ),
			'Right'  => esc_html__( 'Right', 'radio-station' ),
		],
	]
	);

	new \Kirki\Field\Select(
	[
		'settings'    => 'menu_text_transform_radio_station',
		'label'       => esc_html__( 'Menus Text Transform', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => 'CAPITALISE',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'CAPITALISE' => esc_html__( 'CAPITALISE', 'radio-station' ),
			'UPPERCASE' => esc_html__( 'UPPERCASE', 'radio-station' ),
			'LOWERCASE' => esc_html__( 'LOWERCASE', 'radio-station' ),

		],
	]);

		new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_menu_zoom',
		'label'       => esc_html__( 'Menu Transition', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default' => 'None',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'None' => __('None','radio-station'),
            'Zoominn' => __('Zoom Inn','radio-station'),
            
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'slider',
		'settings'    => 'radio_station_container_width',
		'label'       => esc_html__( 'Theme Container Width', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => 100,
		'choices'     => [
			'min'  => 50,
			'max'  => 100,
			'step' => 1,
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_sticky_header',
		'label'       => esc_html__( 'Here you can enable or disable your Sticky Header.', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => false,
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_site_loader',
		'label'       => esc_html__( 'Here you can enable or disable your Site Loader.', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default'     => false,
		'priority'    => 10,
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_page_layout',
		'label'       => esc_html__( 'Page Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_additional_settings',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station'),
            'One Column' => __('One Column','radio-station')
		],
	] );

	if ( class_exists("woocommerce")){

	// Woocommerce Settings

	Kirki::add_section( 'radio_station_woocommerce_settings', array(
			'title'          => esc_html__( 'Woocommerce Settings', 'radio-station' ),
			'panel'          => 'radio_station_panel_id',
			'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_woocommerce_settings',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_shop_sidebar',
		'label'       => esc_html__( 'Here you can enable or disable shop page sidebar.', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default'     => '1',
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_product_sidebar',
		'label'       => esc_html__( 'Here you can enable or disable product page sidebar.', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default'     => '1',
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_related_product_setting',
		'label'       => esc_html__( 'Here you can enable or disable your related products.', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default'     => true,
		'priority'    => 10,
	] );

	new \Kirki\Field\Number(
	[
		'settings' => 'radio_station_per_columns',
		'label'    => esc_html__( 'Product Per Row', 'radio-station' ),
		'section'  => 'radio_station_woocommerce_settings',
		'default'  => 3,
		'choices'  => [
			'min'  => 1,
			'max'  => 4,
			'step' => 1,
		],
	]
	);

	new \Kirki\Field\Number(
	[
		'settings' => 'radio_station_product_per_page',
		'label'    => esc_html__( 'Product Per Page', 'radio-station' ),
		'section'  => 'radio_station_woocommerce_settings',
		'default'  => 9,
		'choices'  => [
			'min'  => 1,
			'max'  => 15,
			'step' => 1,
		],
	]
	);

	new \Kirki\Field\Number(
	[
		'settings' => 'custom_related_products_number_per_row',
		'label'    => esc_html__( 'Related Product Per Column', 'radio-station' ),
		'section'  => 'radio_station_woocommerce_settings',
		'default'  => 3,
		'choices'  => [
			'min'  => 1,
			'max'  => 4,
			'step' => 1,
		],
	]
	);

	new \Kirki\Field\Number(
	[
		'settings' => 'custom_related_products_number',
		'label'    => esc_html__( 'Related Product Per Page', 'radio-station' ),
		'section'  => 'radio_station_woocommerce_settings',
		'default'  => 3,
		'choices'  => [
			'min'  => 1,
			'max'  => 10,
			'step' => 1,
		],
	]
	);

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_shop_page_layout',
		'label'       => esc_html__( 'Shop Page Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station')
		],
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_product_page_layout',
		'label'       => esc_html__( 'Product Page Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station')
		],
	] );

	new \Kirki\Field\Radio_Buttonset(
	[
		'settings'    => 'radio_station_woocommerce_pagination_position',
		'label'       => esc_html__( 'Woocommerce Pagination Alignment', 'radio-station' ),
		'section'     => 'radio_station_woocommerce_settings',
		'default'     => 'Center',
		'priority'    => 10,
		'choices'     => [
			'Left'   => esc_html__( 'Left', 'radio-station' ),
			'Center' => esc_html__( 'Center', 'radio-station' ),
			'Right'  => esc_html__( 'Right', 'radio-station' ),
		],
	]
	);

}

	// POST SECTION

	Kirki::add_section( 'radio_station_section_post', array(
	    'title'          => esc_html__( 'Post Settings', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_section_post',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_post_heading',
		'section'     => 'radio_station_section_post',
		'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Post Settings.', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_blog_admin_enable',
		'label'       => esc_html__( 'Post Author Enable / Disable Button', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default'     => '1',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_blog_comment_enable',
		'label'       => esc_html__( 'Post Comment Enable / Disable Button', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default'     => '1',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'slider',
		'settings'    => 'radio_station_post_excerpt_number',
		'label'       => esc_html__( 'Post Content Range', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default'     => 15,
		'choices'     => [
			'min'  => 0,
			'max'  => 100,
			'step' => 1,
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'toggle',
		'settings'    => 'radio_station_pagination_setting',
		'label'       => esc_html__( 'Here you can enable or disable your Pagination.', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default'     => true,
		'priority'    => 10,
	] );

		new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_archive_sidebar_layout',
		'label'       => esc_html__( 'Archive Post Sidebar Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station'),
            'Three Column' => __('Three Column','radio-station'),
            'Four Column' => __('Four Column','radio-station'),
            'Grid Layout Without Sidebar' => __('Grid Layout Without Sidebar','radio-station'),
            'Grid Layout With Right Sidebar' => __('Grid Layout With Right Sidebar','radio-station'),
            'Grid Layout With Left Sidebar' => __('Grid Layout With Left Sidebar','radio-station')
		],
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_single_post_sidebar_layout',
		'label'       => esc_html__( 'Single Post Sidebar Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station'),
		],
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_search_sidebar_layout',
		'label'       => esc_html__( 'Search Page Sidebar Layout Setting', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default' => 'Right Sidebar',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'Left Sidebar' => __('Left Sidebar','radio-station'),
            'Right Sidebar' => __('Right Sidebar','radio-station'),
            'Three Column' => __('Three Column','radio-station'),
            'Four Column' => __('Four Column','radio-station'),
            'Grid Layout Without Sidebar' => __('Grid Layout Without Sidebar','radio-station'),
            'Grid Layout With Right Sidebar' => __('Grid Layout With Right Sidebar','radio-station'),
            'Grid Layout With Left Sidebar' => __('Grid Layout With Left Sidebar','radio-station')
		],
	] );

	Kirki::add_field( 'radio_station_config', [
		'type'        => 'select',
		'settings'    => 'radio_station_post_column_count',
		'label'       => esc_html__( 'Grid Column for Archive Page', 'radio-station' ),
		'section'     => 'radio_station_section_post',
		'default'    => '2',
		'choices' => [
				'1' => __( '1 Column', 'radio-station' ),
				'2' => __( '2 Column', 'radio-station' ),
			],
	] );

	// Breadcrumb
	Kirki::add_section( 'radio_station_bradcrumb', array(
	    'title'          => esc_html__( 'Breadcrumb Settings', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_bradcrumb',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );


	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_breadcrumb_heading',
		'section'     => 'radio_station_bradcrumb',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Single Page Breadcrumb', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_breadcrumb_enable',
		'label'       => esc_html__( 'Breadcrumb Enable / Disable', 'radio-station' ),
		'section'     => 'radio_station_bradcrumb',
		'default'     => true,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
        'type'     => 'text',
        'default'     => '/',
        'settings' => 'radio_station_breadcrumb_separator' ,
        'label'    => esc_html__( 'Breadcrumb Separator',  'radio-station' ),
        'section'  => 'radio_station_bradcrumb',
    ] );

	// HEADER SECTION

	Kirki::add_section( 'radio_station_section_header', array(
	    'title'          => esc_html__( 'Header Settings', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_section_header',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_search',
		'section'     => 'radio_station_section_header',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Search Box', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_search_box_enable',
		'section'     => 'radio_station_section_header',
		'default'     => '1',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_header_enable_google_translator',
		'section'     => 'radio_station_section_header',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Google Translator Box', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_header_google_translator',
		'section'     => 'radio_station_section_header',
		'default'     => '0',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	// SLIDER SECTION

	Kirki::add_section( 'radio_station_blog_slide_section', array(
        'title'          => esc_html__( ' Slider Settings', 'radio-station' ),
        'panel'          => 'radio_station_panel_id',
        'priority'       => 160,
    ) );

    Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_blog_slide_section',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_heading',
		'section'     => 'radio_station_blog_slide_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Slider', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_blog_box_enable',
		'label'       => esc_html__( 'Section Enable / Disable', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => false,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_title_unable_disable',
		'label'       => esc_html__( 'Slide Title Enable / Disable', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => true,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_button_unable_disable',
		'label'       => esc_html__( 'Slide Button Enable / Disable', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => true,
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_slider_heading',
		'section'     => 'radio_station_blog_slide_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Slider', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'number',
		'settings'    => 'radio_station_blog_slide_number',
		'label'       => esc_html__( 'Number of slides to show', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => 0,
		'choices'     => [
			'min'  => 1,
			'max'  => 5,
			'step' => 1,
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'select',
		'settings'    => 'radio_station_blog_slide_category',
		'label'       => esc_html__( 'Select the category to show slider ( Image Dimension 1600 x 600 )', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => '',
		'placeholder' => esc_html__( 'Select an category...', 'radio-station' ),
		'priority'    => 10,
		'choices'     => radio_station_get_categories_select(),
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'     => 'text',
		'label'       => esc_html__( '1st Heading', 'radio-station' ),
		'settings' => 'radio_station_slider_first_heading',
		'section'  => 'radio_station_blog_slide_section',
		'default'  => '',
		'priority' => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_socail_link',
		'section'     => 'radio_station_blog_slide_section',
		'default'     => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Social Media Link', 'radio-station' ) . '</h3>',
		'priority'    => 100,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'repeater',
		'section'     => 'radio_station_blog_slide_section',
		'priority'    => 101,
		'row_label' => [
			'type'  => 'field',
			'value' => esc_html__( 'Social Icon', 'radio-station' ),
			'field' => 'link_text',
		],
		'button_label' => esc_html__('Add New Social Icon', 'radio-station' ),
		'settings'     => 'radio_station_social_links_settings',
		'default'      => '',
		'fields' 	   => [
			'link_text' => [
				'type'        => 'text',
				'label'       => esc_html__( 'Icon', 'radio-station' ),
				'description' => esc_html__( 'Add the fontawesome class ex: "fab fa-facebook-f".', 'radio-station' ),
				'default'     => '',
			],
			'link_url' => [
				'type'        => 'url',
				'label'       => esc_html__( 'Social Link', 'radio-station' ),
				'description' => esc_html__( 'Add the social icon url here.', 'radio-station' ),
				'default'     => '',
			],
		],
		'choices' => [
			'limit' => 5
		],
	] );

	Kirki::add_field( 'theme_config_id', [
	'type'        => 'custom',
	'settings'    => 'radio_station_footer_enable_heading_22',
	'section'     => 'radio_station_blog_slide_section',
		'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Content Alignment', 'radio-station' ) . '</h3>',
	'priority'    => 10,
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_slider_content_alignment',
		'label'       => esc_html__( 'Slider Content Alignment', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => 'LEFT-ALIGN',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'LEFT-ALIGN' => esc_html__( 'LEFT-ALIGN', 'radio-station' ),
			'CENTER-ALIGN' => esc_html__( 'CENTER-ALIGN', 'radio-station' ),
			'RIGHT-ALIGN' => esc_html__( 'RIGHT-ALIGN', 'radio-station' ),

		],
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_slider_opacity_color',
		'label'       => esc_html__( 'Slider Opacity Option', 'radio-station' ),
		'section'     => 'radio_station_blog_slide_section',
		'default'     => '0.6',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'0' => esc_html__( '0', 'radio-station' ),
			'0.1' => esc_html__( '0.1', 'radio-station' ),
			'0.2' => esc_html__( '0.2', 'radio-station' ),
			'0.3' => esc_html__( '0.3', 'radio-station' ),
			'0.4' => esc_html__( '0.4', 'radio-station' ),
			'0.5' => esc_html__( '0.5', 'radio-station' ),
			'0.6' => esc_html__( '0.6', 'radio-station' ),
			'0.7' => esc_html__( '0.7', 'radio-station' ),
			'0.8' => esc_html__( '0.8', 'radio-station' ),
			'0.9' => esc_html__( '0.9', 'radio-station' ),
			'unset' => esc_html__( 'unset', 'radio-station' ),
		],
	] );

	//RADIO CATEGORY SECTION

	Kirki::add_section( 'radio_station_radio_category_section', array(
	    'title'          => esc_html__( 'Radio Category Settings', 'radio-station' ),
	    'panel'          => 'radio_station_panel_id',
	    'priority'       => 160,
	) );

	Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_radio_category_section',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	    'priority'    => 1,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_enable_heading',
		'section'     => 'radio_station_radio_category_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Radio Category ',  'radio-station' ) . '</h3>',
		'priority'    => 1,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_radio_category_section_enable',
		'label'       => esc_html__( 'Section Enable / Disable',  'radio-station' ),
		'section'     => 'radio_station_radio_category_section',
		'default'     => false,
		'priority'    => 2,
		'choices'     => [
			'on'  => esc_html__( 'Enable',  'radio-station' ),
			'off' => esc_html__( 'Disable',  'radio-station' ),
		],
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_radio_category_heading',
		'section'     => 'radio_station_radio_category_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Radio Category', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'     => 'text',
		'label'       => esc_html__( '1st Heading', 'radio-station' ),
		'settings' => 'radio_station_radio_category_first_heading',
		'section'  => 'radio_station_radio_category_section',
		'default'  => '',
		'priority' => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'     => 'text',
		'label'       => esc_html__( '2nd Heading', 'radio-station' ),
		'settings' => 'radio_station_radio_category_second_heading',
		'section'  => 'radio_station_radio_category_section',
		'default'  => '',
		'priority' => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'number',
		'settings'    => 'radio_station_radio_category_number',
		'label'       => esc_html__( 'Number of radio category to show', 'radio-station' ),
		'section'     => 'radio_station_radio_category_section',
		'default'     => 3,
		'choices'     => [
			'min'  => 0,
			'max'  => 12,
			'step' => 1,
		],
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'select',
		'settings'    => 'radio_station_radio_category',
		'label'       => esc_html__( 'Select the category to show post ( Image Dimension 500 x 500 )', 'radio-station' ),
		'section'     => 'radio_station_radio_category_section',
		'default'     => '',
		'placeholder' => esc_html__( 'Select an category...', 'radio-station' ),
		'priority'    => 10,
		'choices'     => radio_station_get_categories_select(),
	] );

	// FOOTER SECTION

	Kirki::add_section( 'radio_station_footer_section', array(
        'title'          => esc_html__( 'Footer Settings', 'radio-station' ),
        'panel'          => 'radio_station_panel_id',
        'priority'       => 160,
    ) );

    Kirki::add_field( 'theme_config_id', [
	    'label'       => '<span class="custom-label-class">' . esc_html__( 'INFORMATION ABOUT PREMIUM VERSION :-', 'radio-station' ) . '</span>',
	    'default'     => '<a class="premium_info_btn" target="_blank" href="' . esc_url( RADIO_STATION_BUY_NOW ) . '">' . __( 'GO TO PREMIUM', 'radio-station' ) . '</a>',
	    'type'        => 'custom',
	    'section'     => 'radio_station_footer_section',
	    'description' => '<div class="custom-description-class">' . __( '<p>1. One Click Demo Importer </p><p>2. Color Pallete Setup </p><p>3. Section Reordering Facility</p><p>4. For More Options kindly Go For Premium Version.</p>', 'radio-station' ) . '</div>',
	] );

		Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_footer_enable_heading',
		'section'     => 'radio_station_footer_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Enable / Disable Footer Link', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'switch',
		'settings'    => 'radio_station_copyright_enable',
		'label'       => esc_html__( 'Section Enable / Disable', 'radio-station' ),
		'section'     => 'radio_station_footer_section',
		'default'     => '1',
		'priority'    => 10,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'radio-station' ),
			'off' => esc_html__( 'Disable', 'radio-station' ),
		],
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'        => 'custom',
		'settings'    => 'radio_station_footer_text_heading',
		'section'     => 'radio_station_footer_section',
			'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Footer Copyright Text', 'radio-station' ) . '</h3>',
		'priority'    => 10,
	] );

    Kirki::add_field( 'theme_config_id', [
		'type'     => 'text',
		'settings' => 'radio_station_footer_text',
		'section'  => 'radio_station_footer_section',
		'default'  => '',
		'priority' => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
	'type'        => 'custom',
	'settings'    => 'radio_station_footer_text_heading_2',
	'section'     => 'radio_station_footer_section',
	'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Footer Copyright Alignment', 'radio-station' ) . '</h3>',
	'priority'    => 10,
	] );

	new \Kirki\Field\Select(
	[
		'settings'    => 'radio_station_copyright_text_alignment',
		'label'       => esc_html__( 'Copyright text Alignment', 'radio-station' ),
		'section'     => 'radio_station_footer_section',
		'default'     => 'LEFT-ALIGN',
		'placeholder' => esc_html__( 'Choose an option', 'radio-station' ),
		'choices'     => [
			'LEFT-ALIGN' => esc_html__( 'LEFT-ALIGN', 'radio-station' ),
			'CENTER-ALIGN' => esc_html__( 'CENTER-ALIGN', 'radio-station' ),
			'RIGHT-ALIGN' => esc_html__( 'RIGHT-ALIGN', 'radio-station' ),

		],
	] );

	Kirki::add_field( 'theme_config_id', [
	'type'        => 'custom',
	'settings'    => 'radio_station_footer_text_heading_1',
	'section'     => 'radio_station_footer_section',
	'default'         => '<h3 style="color: #2271b1; padding:10px; background:#fff; margin:0; border-left: solid 5px #2271b1; ">' . __( 'Footer Copyright Background Color', 'radio-station' ) . '</h3>',
	'priority'    => 10,
	] );

	Kirki::add_field( 'theme_config_id', [
		'type'        => 'color',
		'settings'    => 'radio_station_copyright_bg',
		'label'       => __( 'Choose Your Copyright Background Color', 'radio-station' ),
		'section'     => 'radio_station_footer_section',
		'default'     => '',
	] );
}

/*
 *  Customizer Notifications
 */

$radio_station_config_customizer = array(
    'recommended_plugins' => array( 
        'kirki' => array(
            'recommended' => true,
            'description' => sprintf( 
                /* translators: %s: plugin name */
                esc_html__( 'If you want to show all the sections of the FrontPage, please install and activate %s plugin', 'radio-station' ), 
                '<strong>' . esc_html__( 'Kirki Customizer', 'radio-station' ) . '</strong>'
            ),
        ),
    ),
    'radio_station_recommended_actions'       => array(),
    'radio_station_recommended_actions_title' => esc_html__( 'Recommended Actions', 'radio-station' ),
    'radio_station_recommended_plugins_title' => esc_html__( 'Recommended Plugin', 'radio-station' ),
    'radio_station_install_button_label'      => esc_html__( 'Install and Activate', 'radio-station' ),
    'radio_station_activate_button_label'     => esc_html__( 'Activate', 'radio-station' ),
    'radio_station_deactivate_button_label'   => esc_html__( 'Deactivate', 'radio-station' ),
);

Radio_Station_Customizer_Notify::init( apply_filters( 'radio_station_customizer_notify_array', $radio_station_config_customizer ) );