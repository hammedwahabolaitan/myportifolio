=== Radio Station ===
Contributors: misbahwp
Tags: entertainment, photography, blog, wide-blocks, one-column, two-columns, three-columns, four-columns, right-sidebar, left-sidebar, grid-layout, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-images, footer-widgets, full-width-template, featured-image-header, editor-style, post-formats, theme-options, threaded-comments, rtl-language-support, sticky-post, translation-ready
Requires at least: 5.0
Stable tag: 4.4
Requires PHP: 7.2
Tested up to: 6.7
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

One amazing WordPress theme that is available for free usage is called Radio Station. This theme can be used to construct a sophisticated and modern website for radio stations, online radios, radio DJs, radio shows, etc.

== Description ==

One amazing WordPress theme that is available for free usage is called Radio Station. This theme can be used to construct a sophisticated and modern website for radio stations, online radios, radio DJs, radio shows, etc. With the help of this WordPress theme for radio, singers, bands, DJs, and scheduled podcasts may all host their shows on the radio. In addition to supporting icecast and shoutcast for streaming, it has an MP3 player built in. In addition to having a sophisticated design, the theme is translation-ready, supporting both local and international languages. This theme's developers took a basic approach when developing it, which allowed for extreme optimization to guarantee quicker page loads. Additionally, SEO-friendly coding helps you rank higher in search results.Custom logos and Google fonts can be added to your website using the customizer's personalization options. This theme is excellent in terms of its user-friendly interface. Your website will function flawlessly on all devices if it has an eye-catching banner, a testimonial area, and a responsive design. To guarantee that mobile users enjoy an exceptional experience, it is mobile-friendly. Better conversion rates are anticipated from your website if it has Call to Action (CTA) buttons all over it. It runs smoothly thanks to the safe and orderly HTML coding, and the Bootstrap framework gives your website a solid foundation. Additionally, it enables events for booking performances or concerts, a gallery for displaying albums and discography, and material design.

== Changelog ==

= 1.0 = April - 01 - 2022

* Initial version.

= 1.1 = May - 06 - 2022

* Added get-started.
* Updated footer link.

= 1.2 = June - 03 - 2022

* Added additional settings.

= 1.3 = July - 08 - 2022

* Added typography.

= 1.4 = August - 30 - 2022

* Added container width settings.
* Added menu text-transform settings.
* Added RTL support.

= 1.5 = November - 24 - 2022

* Resolved theme issues.

= 1.6 = December - 24 - 2022

* Resolve slider error.
* Added web-font file.
* Updated header settings.

= 1.7 = January - 17 - 2023

* Added slider content alignment settings.
* Added google font licence.

= 1.8 = February - 16 - 2023

* Added woocommerce settings.
* Resolve minor errors.

= 1.9 = March - 18 - 2023

* Added sticky header.
* Updated woocommerce files.

= 2.0 = May - 12 - 2023

* Added copyright background settings.
* Added copyright alignment settings.
* Updated PHP version.

= 2.1 = June - 1 - 2023

* Added headings in customizer.
* Updated section on off settings.

= 2.2 = June - 24 - 2023

* Added preloader.
* Added related product settings.
* Updated PHP version.

= 2.3 = July - 7 - 2023

* Added scroll to top alignment settings.
* Added Pagination settings.

= 2.4 = August - 02 - 2023

* Added product per page settings.
* Added product per column settings.

= 2.5 = August - 29 - 2023

* Added slider alternate image.
* Resolve fallback menu error.
* Updated slider alignment settings.
* Added woocommerce condition in customizer.
* Remove sticky from 768 media.
* Added block post CSS.

= 2.6 = September - 15 - 2023

* Updated media.css file.
* Added sticky post tag CSS.
* added gallery block CSS.

= 2.7 = September - 28 - 2023

* Added theme bundle detail in get-start.
* Added pro demo button in customizer.
* Added default blocks CSS.

= 2.8 = October - 22 - 2023

* Added post format tag.
* Added partial refresh for customizer.

= 2.9 = November - 11 - 2023

* Added notice bar in admin panel.
* Added sidebar adjustment settings in shop page.
* Added sidebar adjustment settings in product page.
* Added sidebar adjustment settings in page.

= 3.0 = November - 20 - 2023

* Added JS file for admin.
* Updated notice function.
* Added slider opacity option.
* Added slider overlay option.
* Added slider background color option.

= 3.1 = December - 21 - 2023

* Added setting for single post sidebar.
* Added setting for archive post sidebar.
* Added setting for search page post sidebar.
* Added Default sidebar.
* Updated WordPress version.
* Updated customizer settings.
* Updated admin CSS.
* Added checkout or Cart page CSS.

= 3.2 = January - 19 - 2024

* Added featured header image tag.
* Added woocommerce pages alignment setting.
* Added block CSS.
* Added pagination colors for woocommerce.
* Updated sticky post CSS.

= 3.3 = January - 25 - 2024

* Added footer widgets in preview.
* Updated pages CSS in responsive media.
* Resolve responsive Menu CSS.

= 3.4 = February - 08 - 2024

* Added related product per page settings.
* Added related product per column settings.
* Added archive page column settings.
* Updated 60 to 80+ themes in get-start.
* Updated header feature image CSS.

= 3.5 = February - 29 - 2024

* Added menu settings.
* Resolve logo resizer issue.
* Added TGM licence.
* Done prefixing in files.

= 3.6 = April - 16 - 2024

* Updated bundle details in getstart.
* Updated featured header image heading in media.
* Added breadcrumb setting.
* Updated boostrap.css file.
* Remove echo from logo section.
* Remove partial refresh settings.

= 3.7 = May - 13 - 2024

* Changed pro themes URL.
* Changed lite themes URL.
* Changed demo URL.
* Changed lite doc URL.
* Changed pro doc URL.
* Changed bundle URL.

= 3.8 = May - 27 - 2024

* Added alterate image in category section.
* Updated notice function.
* Updated bootstrap container.
* Updated slider alignment settings.

= 3.9 = June - 18 - 2024

* Added premium feature box in every section in theme options.
* Updated bundle details.
* Updated PHP version.
* Updated Customizer.
* Updated WordPress version.
* Updated woocommerce archive product template.

= 4.0 = July - 18 2024

* Added kirki customizer recommendation.
* Enqueue Dashicons.
* Remove / from Pro, Lite or Bundle URLs.
* Updated page layout setting.

= 4.1 = August - 12 - 2024

* Added tag 3 columns.
* Added tag 4 columns.
* Updated grid layout settings.
* Updated WordPress version.
* Updated escaping in customizer.
* Updated slider settings.
* Updated footer block CSS.
* Added breadcrumb settings.

= 4.2 = September - 7 - 2024

* Added demo importer.
* Added POT file.
* Added keywords.
* Added global color.

= 4.3 = October - 18 - 2024

* Added dark mode option.
* Updated woocommerce templates.
* Added CSS for customizer.

= 4.4 = November - 15 - 2024

* Added animation.
* Added animate.css file.
* Added wow.js file.
* Updated woocommerce template.
* Updated customizer CSS.

== Resources ==

Radio Station WordPress Theme, Copyright 2022 misbahwp
Radio Station is distributed under the terms of the GNU GPL.

Google Web Fonts (Maven Pro) By Google - https://google.com
* Maven Pro is a sans-serif typeface with unique curvature, Licensed under Open Font License, https://fonts.google.com/specimen/Maven+Pro?query=Maven+Pro

Bootstrap v5.1.3 (https://getbootstrap.com) Copyright 2011-2021 The Bootstrap Authors
* Copyright 2011-2021 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

Font Awesome Free 5.0.6 by @fontawesome - http://fontawesome.com
* License - http://fontawesome.com/license (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

Owl Carousel v2.3.4 Copyright 2013-2018 David Deutsch
* Licensed under: SEE LICENSE IN https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE

Kirki Customizer Framework v3.0.45 Copyright (c) 2019, Ari Stathopoulos (@aristath)
* License URI: https://opensource.org/licenses/MIT (License: MIT)

navigation.js file By Automattic, Inc. - https://underscores.me/
* navigation.js - Licensed under GPLv2 or later ( Applies to navigation.js file in /radio-station/js/ )

Webfonts Loader
* https://github.com/WPTT/webfont-loader
* License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE

TGMPA, GaryJones Copyright (C) 1989, 1991
* https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md
* License: GNU General Public License v2.0

Screenshot images By stocksnap - https://stocksnap.io

* Featured image : https://stocksnap.io/photo/recording-studio-YA3HZPUFYL - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/microphone-audio-IQVHQYS3GL - License: CC0 Public Domain

* Featured image : https://stocksnap.io/photo/perform-band-ZUFKPLIZ2Z - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/guitarist-music-XJEJGKFZBM - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/concert-singer-7OC4YX7S20 - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/guy-man-T9FBXCLG7C - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/architecture-building-4VLAUXBETL - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/electrickeyboard-piano-Q4PMYILN33 - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/neon-sign-OMECCADMRG - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/man-music-JSDMDDA208 - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/women-nightlife-CW5XYORZIJ - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/urban-fashion-FGIC1RJYQN - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/woman-summer-68FQPPGUHG - License: CC0 Public Domain
* Featured image : https://stocksnap.io/photo/people-man-2UR26DBTZZ - License: CC0 Public Domain
* Featured image : https://pxhere.com/en/photo/1580813 - License: CC0 Public Domain
